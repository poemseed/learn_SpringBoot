package com.koreait.springtestquest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringtestquestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringtestquestApplication.class, args);
	}

}
