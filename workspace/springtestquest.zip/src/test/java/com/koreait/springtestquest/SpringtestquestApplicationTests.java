package com.koreait.springtestquest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringtestquestApplicationTests {

	@Test
	void contextLoads() {
	}

}
