package com.koreait.Springtest4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springtest4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
