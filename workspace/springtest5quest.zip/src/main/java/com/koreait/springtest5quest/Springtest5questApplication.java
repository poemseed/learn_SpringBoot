package com.koreait.springtest5quest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springtest5questApplication {

	public static void main(String[] args) {
		SpringApplication.run(Springtest5questApplication.class, args);
	}

}
