package com.koreait.springtest5quest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springtest5questApplicationTests {

	@Test
	void contextLoads() {
	}

}
